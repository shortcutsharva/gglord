import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:wellverse/shared/or.dart';
import 'package:wellverse/shared/styles.dart';

class Register extends StatefulWidget {
  const Register({Key? key}) : super(key: key);

  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  final double indent = 20;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Image.asset(
          "assets/wellverse_mini.png",
          scale: 2,
        ),
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(
            vertical: 30,
            horizontal: (MediaQuery.of(context).size.width - 320) / 2),
        child: ListView(
          physics: BouncingScrollPhysics(),
          //mainAxisAlignment: MainAxisAlignment.spaceAround,
          //crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Let's get started...",
              style: headingStyle,
            ),
            SizedBox(
              height: 34,
            ),
            SizedBox(
                width: 320,
                height: 50,
                child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10))),
                    onPressed: () {},
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image.asset(
                          "assets/google_logo.png",
                          scale: 2,
                        ),
                        SizedBox(
                          width: 16,
                        ),
                        Text(
                          "Register with Google",
                          style: TextStyle(color: navyblue, fontSize: 16),
                        ),
                      ],
                    ))),
            Or(
              height: 60,
            ),
            TextFormField(
              decoration: inputverse.copyWith(hintText: "Username"),
            ),
            SizedBox(height: indent),
            TextFormField(
              decoration: inputverse.copyWith(hintText: "Password"),
            ),
            SizedBox(height: indent),
            TextFormField(
              decoration: inputverse.copyWith(hintText: "Confirm Password"),
            ),
            SizedBox(height: indent),
            TextFormField(
              decoration: inputverse.copyWith(hintText: "Email ID"),
            ),
            SizedBox(height: indent),
            TextFormField(
              decoration: inputverse.copyWith(hintText: "Confirm Email ID"),
            ),
            Divider(
              height: 60,
              thickness: 1,
            ),
            SizedBox(
              width: 320,
              height: 60,
              child: TextButton(
                onPressed: () {
                  Navigator.pushNamed(context, '/questions');
                },
                style: TextButton.styleFrom(
                    backgroundColor: purpleverse,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10))),
                child: Text(
                  "Sign Up",
                  style: whiteTextStyle,
                ),
              ),
            ),
            Or(
              height: 70,
            ),
            SizedBox(
                width: 320,
                height: 60,
                child: OutlinedButton(
                  onPressed: () {
                    Navigator.pushReplacementNamed(context, '/login');
                  },
                  child: RichText(
                    text: TextSpan(
                        style: TextStyle(color: navyblue, fontSize: 18),
                        children: <TextSpan>[
                          TextSpan(text: "Already a member? "),
                          TextSpan(
                              text: "Login",
                              style: TextStyle(fontWeight: FontWeight.bold))
                        ]),
                  ),
                  style: OutlinedButton.styleFrom(
                      side: BorderSide(color: purpleverse),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10))),
                ))
          ],
        ),
      ),
    );
  }
}
