import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:wellverse/shared/or.dart';
import 'package:wellverse/shared/styles.dart';

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        centerTitle: true,
        title: Image.asset(
          "assets/wellverse_mini.png",
          scale: 2,
        ),
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(
            vertical: 30,
            horizontal: (MediaQuery.of(context).size.width - 320) / 2),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Jump right back in...", style: headingStyle),
            // SizedBox(
            //   height: 35,
            // ),
            TextFormField(
                decoration: InputDecoration(
                    hintText: "Username",
                    focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: neonGreen),
                        borderRadius: BorderRadius.circular(10)),
                    enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey),
                        borderRadius: BorderRadius.circular(10)))),
            // SizedBox(
            //   height: 30,
            // ),
            TextFormField(
                decoration: InputDecoration(
                    hintText: "Password",
                    focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: neonGreen),
                        borderRadius: BorderRadius.circular(10)),
                    enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(color: Colors.grey),
                        borderRadius: BorderRadius.circular(10)))),
            // SizedBox(
            //   height: 35,
            // ),
            SizedBox(
              width: 320,
              height: 60,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom(
                    backgroundColor: purpleverse,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10))),
                child: Text(
                  "Log In",
                  style: whiteTextStyle,
                ),
              ),
            ),
            Or(),
            SizedBox(
                width: 320,
                height: 50,
                child: OutlinedButton(
                  onPressed: () {},
                  style: OutlinedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10))),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset(
                        "assets/google_logo.png",
                        scale: 2,
                      ),
                      SizedBox(
                        width: 16,
                      ),
                      Text(
                        "Log In with Google",
                        style: TextStyle(color: navyblue, fontSize: 16),
                      ),
                    ],
                  ),
                )),
            SizedBox(
                width: 320,
                height: 50,
                child: OutlinedButton(
                    style: OutlinedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10))),
                    onPressed: () {},
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Image.asset(
                          "assets/twitter_logo.png",
                          scale: 2,
                        ),
                        SizedBox(
                          width: 16,
                        ),
                        Text(
                          "Log In with Twitter",
                          style: TextStyle(color: navyblue, fontSize: 16),
                        ),
                      ],
                    ))),
            Or(),
            SizedBox(
                width: 320,
                height: 60,
                child: OutlinedButton(
                  onPressed: () {},
                  style: OutlinedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10))),
                  child: RichText(
                    text: TextSpan(
                        style: TextStyle(color: navyblue, fontSize: 18),
                        children: const <TextSpan>[
                          TextSpan(text: "New Here? "),
                          TextSpan(
                              text: "Sign Up",
                              style: TextStyle(fontWeight: FontWeight.bold))
                        ]),
                  ),
                ))
          ],
        ),
      ),
    );
  }
}
