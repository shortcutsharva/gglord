import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

import '../shared/imageHelper.dart';

class VRImage extends StatelessWidget {
  VRImage({super.key, required this.imgpath});
  String imgpath;
  double PI = 3.1415926535;

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () {
          SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual,
              overlays: SystemUiOverlay.values);
          return Future.value(true);
        },
        child: GestureDetector(
          onTap: (() {
            SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual,
                overlays: SystemUiOverlay.values);
            Navigator.pop(context);
          }),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Transform.rotate(
                angle: PI / 2,
                child: CachedNetworkImage(
                  imageUrl: imgpath,
                  errorWidget: onError,
                ),
              ),
              Transform.rotate(
                angle: PI / 2,
                child: CachedNetworkImage(
                  imageUrl: imgpath,
                  errorWidget: onError,
                ),
              ),
            ],
          ),
        ));
  }
}
