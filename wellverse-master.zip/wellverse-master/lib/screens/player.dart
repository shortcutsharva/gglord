import 'dart:async';
import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_blue/flutter_blue.dart';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import 'package:wellverse/screens/VRImage.dart';
import 'package:wellverse/services/BluetoothHelper.dart';
import 'package:wellverse/shared/imageHelper.dart';
import 'package:wellverse/shared/styles.dart';

import '../models/Song.dart';

enum IntensityLevel { low, medium, high }

Map<IntensityLevel, double> intensityMultiplierList = {
  IntensityLevel.low: 1.0,
  IntensityLevel.medium: 1.25,
  IntensityLevel.high: 1.5,
};

class Player extends StatefulWidget {
  Player({
    Key? key,
    required this.currentPlayingSong,
    required this.d,
    required this.cachedImgPath,
    required this.loops,
  }) : super(key: key);

  final Song currentPlayingSong;
  final BluetoothDevice d;
  final int loops;
  final String? cachedImgPath;

  @override
  State<Player> createState() => _PlayerState();
}

class _PlayerState extends State<Player> {
  bool isPaused = false;
  int loop = 1;
  late AudioPlayer player;
  Duration? songLength;
  List<double> speedUIList = [0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0];
  List<int> speedCodesList = [40, 35, 30, 25, 20, 18, 15];
  List<double> speedsList = [0.75, 0.857, 1, 1.2, 1.5, 1.666, 2];
  int speedIndex = 2;
  bool muted = true;
  final stopString = "0,0,0,0";

  final storageRef = FirebaseStorage.instance.ref();
  String? dowurl;
  String? songurl;
  File? songCachePath;
  Future? _future;

  IntensityLevel intensityLevel = IntensityLevel.low;
  // Define a variable to store the current position
  Duration? currentPosition;

  Future<void> initPlayer() async {
    await Future.delayed(Duration(seconds: 1));
    await startSong(widget.loops, speedsList[speedIndex]);
    sendData(widget.d,
        "1,${widget.loops},${speedCodesList[speedIndex]},${widget.currentPlayingSong.songId}");
  }

  void sendStop() async {
    sendData(widget.d, stopString);
    await Future.delayed(Duration(milliseconds: 100));
    sendData(widget.d, stopString);
  }

  @override
  void initState() {
    super.initState();
    sendStop();
    loadFile();
    initPlayer();
    storageRef
        .child(widget.currentPlayingSong.imgpath)
        .getDownloadURL()
        .then((url) {
      print(url);
      setState(() => dowurl = url);
    });
  }

  @override
  void dispose() {
    super.dispose();
    player.dispose();
  }

  Future<String> getSongUrl() async {
    return await storageRef
        .child(widget.currentPlayingSong.songpath)
        .getDownloadURL();
  }

  Future<void> loadFile() async {
    if (songurl == null) {
      songurl = await getSongUrl();
    }
    songCachePath = await DefaultCacheManager().getSingleFile(songurl!);
    print("\nLoaded File\n");
  }

  Future<void> startSong(int loops, double speed) async {
    if (songCachePath == null) {
      await loadFile();
    }
    player = AudioPlayer();
    if (muted) await player.setVolume(0);
    await player.setPlaybackRate(speed);

    // Check if there's a stored position and resume from there if available
    if (currentPosition != null) {
      await player.seek(currentPosition!);
    }

    await player.play(DeviceFileSource(songCachePath!.path));
    player.onPlayerComplete.listen((event) async {
      print("Playing at loop: ${loop}");
      if (loop == widget.loops) {
        Navigator.pop(context);
        stopSong();
        sendStop();
      } else {
        await player.stop();
        player.play(DeviceFileSource(songCachePath!.path));
      }

      setState(() {
        loop++;
      });
    });
  }

  Future<void> stopSong() async {
    await player.stop();
  }

  void multiplyIntensity(List<int> data) {
    double intensityMultiplier = intensityMultiplierList[intensityLevel] ?? 1.0;
    for (int i = 1; i < data.length; i += 2) {
      data[i] = (data[i] * intensityMultiplier).round();
    }
  }

  void sendDataWithIntensity(BluetoothDevice device, String dataString) {
    List<int> data = dataString.split(',').map(int.parse).toList();
    multiplyIntensity(data);
    sendData(device, data.join(','));
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        // Store the current position when the app is paused
        currentPosition = await player.getCurrentPosition();
        stopSong();
        sendStop();
        return true;
      },
      child: Scaffold(
        appBar: AppBar(
          title: Image.asset("assets/wellverse_mini.png", scale: 2),
          centerTitle: true,
          actions: [IconButton(onPressed: () {}, icon: Icon(Icons.menu))],
        ),
        body: Padding(
          padding: EdgeInsets.symmetric(
            vertical: 20,
            horizontal: (MediaQuery.of(context).size.width - 340) / 2,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SizedBox(),
              Column(
                children: [
                  Text(
                    widget.currentPlayingSong.title,
                    style: headingStyle,
                  ),
                  Text(
                    "${loop}/${widget.loops}",
                    style: TextStyle(color: Colors.grey, fontSize: 18),
                  ),
                ],
              ),
              GestureDetector(
                onTap: () {
                  SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual,
                      overlays: []);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => VRImage(
                        imgpath: widget.cachedImgPath ?? dowurl!,
                      ),
                    ),
                  );
                },
                child: (() {
                  if (widget.cachedImgPath != null) {
                    return CachedNetworkImage(
                      imageUrl: widget.cachedImgPath!,
                      width: 300,
                      placeholder: ((context, url) {
                        return Image.asset(
                          "assets/images/ganapathi.png",
                          width: 300,
                        );
                      }),
                    );
                  }

                  if (widget.cachedImgPath == null) {
                    if (dowurl == null) {
                      return Image.asset(
                        "assets/images/ganapathi.png",
                        width: 300,
                      );
                    }
                    return CachedNetworkImage(
                      imageUrl: dowurl!,
                      width: 300,
                      placeholder: ((context, url) {
                        return Image.asset(
                          "assets/images/ganapathi.png",
                          width: 300,
                        );
                      }),
                      errorWidget: onError,
                    );
                  }
                }()),
              ),
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SizedBox(
                        width: 165,
                        height: 60,
                        child: TextButton(
                          onPressed: () async {
                            Song currSong = widget.currentPlayingSong;

                            if (!isPaused) {
                              sendStop();
                              stopSong();
                            } else {
                              sendDataWithIntensity(widget.d,
                                  "1,${widget.loops - loop + 1},${speedCodesList[speedIndex]},${currSong.songId}");
                              startSong(
                                  widget.loops - loop, speedsList[speedIndex]);
                            }

                            setState(() {
                              isPaused = !isPaused;
                            });
                          },
                          style: TextButton.styleFrom(
                            backgroundColor: purpleverse,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                !isPaused ? Icons.pause : Icons.play_arrow,
                                color: Colors.white,
                              ),
                              SizedBox(width: 10),
                              Text(
                                !isPaused ? "Pause" : "Play",
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Colors.white,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 165,
                        height: 60,
                        child: TextButton(
                          onPressed: () async {
                            if (speedIndex < speedsList.length - 1) {
                              setState(() {
                                speedIndex++;
                              });
                            } else {
                              setState(() {
                                speedIndex = 0;
                              });
                            }

                            if (isPaused) {
                              return;
                            }

                            sendStop();
                            await stopSong();

                            Future.delayed(Duration(milliseconds: 200), () {
                              sendDataWithIntensity(widget.d,
                                  "1,${widget.loops - loop + 1},${speedCodesList[speedIndex]},${widget.currentPlayingSong.songId},");
                              startSong(
                                  widget.loops - loop, speedsList[speedIndex]);
                            });
                          },
                          style: TextButton.styleFrom(
                            backgroundColor: purpleverse,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                          ),
                          child: Text(
                            "Speed: ${speedUIList[speedIndex]}x",
                            style: TextStyle(
                              fontSize: 18,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SizedBox(
                        width: 245,
                        height: 60,
                        child: OutlinedButton(
                          onPressed: () {
                            sendStop();
                            Navigator.pop(context);
                            stopSong();
                          },
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.close,
                                color: Color(0xff9F1010),
                              ),
                              SizedBox(width: 5),
                              Text(
                                "End Program",
                                style: TextStyle(
                                  fontSize: 18,
                                  color: Color(0xff9F1010),
                                ),
                              ),
                            ],
                          ),
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(
                              color: purpleverse,
                              width: 3,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 85,
                        height: 60,
                        child: IconButton(
                          onPressed: () {
                            if (muted) {
                              player.setVolume(1);
                            } else {
                              player.setVolume(0);
                            }

                            setState(() {
                              muted = !muted;
                            });
                          },
                          icon: Icon(
                            muted ? Icons.volume_off : Icons.volume_up,
                          ),
                          iconSize: 40,
                          color: purpleverse,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      SizedBox(
                        width: 165,
                        height: 60,
                        child: TextButton(
                          onPressed: () {
                            setState(() {
                              switch (intensityLevel) {
                                case IntensityLevel.low:
                                  intensityLevel = IntensityLevel.medium;
                                  break;
                                case IntensityLevel.medium:
                                  intensityLevel = IntensityLevel.high;
                                  break;
                                case IntensityLevel.high:
                                  intensityLevel = IntensityLevel.low;
                                  break;
                              }
                            });
                          },
                          style: TextButton.styleFrom(
                            backgroundColor: purpleverse,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                          ),
                          child: Text(
                            "Intensity: ${intensityLevel.toString().split('.').last}",
                            style: TextStyle(
                              fontSize: 18,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
