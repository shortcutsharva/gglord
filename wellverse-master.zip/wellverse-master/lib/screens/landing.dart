import 'package:flutter/material.dart';
import 'package:wellverse/screens/auth/login.dart';
import 'package:wellverse/screens/linking/connecting.dart';
import 'package:wellverse/shared/or.dart';
import 'package:wellverse/shared/styles.dart';

class Landing extends StatelessWidget {
  const Landing({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Padding(
      padding: EdgeInsets.symmetric(
          horizontal: (MediaQuery.of(context).size.width - 320) / 2),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          SizedBox(),
          Center(
            child: Image.asset(
              "assets/wellverse_logo_full.png",
              scale: 1.5,
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                width: 320,
                height: 60,
                decoration: BoxDecoration(
                  gradient: purpleGradient,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: TextButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => BluetoothScreen()));
                  },
                  style: ButtonStyle(
                    backgroundColor:
                        MaterialStateProperty.all<Color>(Colors.transparent),
                    shadowColor:
                        MaterialStateProperty.all<Color>(Colors.transparent),
                  ),
                  child: Text(
                    "Get Started",
                    style: whiteTextStyle,
                  ),
                ),
              ),
              // Or(),
              // SizedBox(
              //   width: 320,
              //   height: 60,
              //   child: TextButton(
              //     onPressed: () {
              //       Navigator.push(context,
              //           MaterialPageRoute(builder: (context) => Login()));
              //     },
              //     style: TextButton.styleFrom(
              //         backgroundColor: navyblue,
              //         shape: RoundedRectangleBorder(
              //             borderRadius: BorderRadius.circular(20))),
              //     child: Text(
              //       "Log In",
              //       style: whiteTextStyle,
              //     ),
              //   ),
              // ),
              SizedBox(height: 45) //prev 30
            ],
          ),
        ],
      ),
    ));
  }
}
