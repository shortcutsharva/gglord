import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:wellverse/shared/styles.dart';

class Questions extends StatefulWidget {
  const Questions({Key? key}) : super(key: key);

  @override
  State<Questions> createState() => _QuestionsState();
}

class _QuestionsState extends State<Questions> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Image.asset("assets/wellverse_mini.png", scale: 2),
        centerTitle: true,
        actions: [IconButton(onPressed: () {}, icon: Icon(Icons.menu))],
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(
          vertical: 30,
          horizontal: (MediaQuery.of(context).size.width - 340) / 2,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              "Answer a few questions before we proceed...",
              style: headingStyle,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "1/12",
                  style: TextStyle(
                      color: Colors.grey,
                      fontWeight: FontWeight.bold,
                      fontSize: 18),
                ),
                SizedBox(height: 20),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 5),
                  child: Text(
                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit?",
                    style: TextStyle(fontSize: 18, color: navyblue),
                  ),
                )
              ],
            ),
            Column(
              children: [
                SizedBox(
                    width: 340,
                    height: 60,
                    child: OutlinedButton(
                      onPressed: () {
                        Navigator.pushNamed(context, '/subscribe');
                      },
                      child: Text(
                        "YES",
                        style: purpleTextStyle,
                      ),
                      style: OutlinedButton.styleFrom(
                          side: BorderSide(color: purpleverse, width: 3),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20))),
                    )),
                SizedBox(height: 20),
                SizedBox(
                  width: 340,
                  height: 60,
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom(
                        backgroundColor: purpleverse,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20))),
                    child: Text(
                      "NO",
                      style: whiteTextStyle,
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
