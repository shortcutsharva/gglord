import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:wellverse/shared/plan_card.dart';
import 'package:wellverse/shared/styles.dart';

class Subscribe extends StatefulWidget {
  const Subscribe({Key? key}) : super(key: key);

  @override
  State<Subscribe> createState() => _SubscribeState();
}

class _SubscribeState extends State<Subscribe> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Image.asset("assets/wellverse_mini.png", scale: 2),
        centerTitle: true,
        actions: [IconButton(onPressed: () {}, icon: Icon(Icons.menu))],
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              children: [
                Text(
                  "Subscribe",
                  style: TextStyle(
                      fontSize: 20,
                      color: purpleverse,
                      fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  height: 10,
                ),
                Divider(
                  thickness: 3,
                  color: purpleverse.withAlpha(77),
                )
              ],
            ),
          ),
          Flexible(
            child: CarouselSlider(
              options: CarouselOptions(
                aspectRatio: 0.9,
                enlargeCenterPage: true,
                enableInfiniteScroll: true,
                initialPage: 1,
                autoPlay: false,
                viewportFraction: 0.65,
              ),
              items: [PlanCard(), PlanCard(), PlanCard()],
            ),
          ),
          SizedBox()
        ],
      ),
    );
  }
}
