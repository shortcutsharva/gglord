import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_blue/flutter_blue.dart';
import 'package:loading_overlay/loading_overlay.dart';
import 'package:wellverse/screens/suggested_programs.dart';

import '../../shared/styles.dart';

class BluetoothScreen extends StatelessWidget {
  BluetoothScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<BluetoothState>(
      stream: FlutterBlue.instance.state,
      initialData: BluetoothState.unknown,
      builder: (c, snapshot) {
        final state = snapshot.data;
        if (state == BluetoothState.off) {
          return BluetoothOffScreen();
        } else {
          return Connecting();
        }
      },
    );
  }
}

class BluetoothOffScreen extends StatelessWidget {
  const BluetoothOffScreen({Key? key, this.state}) : super(key: key);
  final BluetoothState? state;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Image.asset("assets/wellverse_mini.png", scale: 2),
        centerTitle: true,
        actions: [IconButton(onPressed: () {}, icon: Icon(Icons.menu))],
      ),
      body: Container(
        width: double.infinity,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            SizedBox(
              height: 0.05 * MediaQuery.of(context).size.height,
            ),
            Icon(
              Icons.bluetooth_disabled,
              size: 140.0,
              color: purpleverse,
            ),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Text(
                'Bluetooth Adapter is ${state != null ? state.toString().substring(15) : 'not available'}.\nPlease turn it on',
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class Connecting extends StatefulWidget {
  const Connecting({Key? key}) : super(key: key);

  @override
  State<Connecting> createState() => _ConnectingState();
}

class _ConnectingState extends State<Connecting> {
  FlutterBlue flutterBlue = FlutterBlue.instance;
  List<ScanResult> scanResultList = [];
  bool showScanResults = false;
  bool isScanning = false;
  bool isLoading = false;

  scan() async {
    if (isScanning) {
      await flutterBlue.stopScan();
      await Future.delayed(Duration(milliseconds: 50));
    }
    scanResultList.clear();
    print("Setting isScanning to true");
    isScanning = true;
    flutterBlue.startScan(timeout: const Duration(seconds: 4)).then((value) {
      print("Setting isScanning to false");
      isScanning = false;
    });
    flutterBlue.scanResults.listen((results) {
      if (mounted) {
        setState(() {
          scanResultList = results;
        });
      }
    });
  }

  Widget listItem(ScanResult r) {
    return ListTile(
      onTap: () => onTap(r),
      leading: leading(r),
      title: deviceName(r),
      subtitle: deviceMacAddress(r),
    );
  }

  @override
  void initState() {
    super.initState();
    autoConnectToDevice();
  }

  void autoConnectToDevice() async {
    List<BluetoothDevice> connectedDevices = await flutterBlue.connectedDevices;

    if (connectedDevices.isNotEmpty) {
      BluetoothDevice lastConnectedDevice = connectedDevices.first;

      // Attempt to connect to the last connected device
      setState(() {
        isLoading = true;
      });
      lastConnectedDevice.connect().timeout(
        Duration(seconds: 10),
        onTimeout: () {
          // If connection attempt times out, mark the device as unavailable
          setState(() {
            isLoading = false;
          });
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text("Unable to connect to the last connected device."),
          ));
        },
      );
      late StreamSubscription<BluetoothDeviceState> stateSub;
      stateSub = lastConnectedDevice.state.listen((state) {
        if (state == BluetoothDeviceState.connected) {
          // If the device is successfully connected, navigate to the next screen
          setState(() {
            isLoading = false;
          });
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (context) => SuggestedPrograms(d: lastConnectedDevice),
            ),
          );
          stateSub.cancel();
        }
      });
    } else {
      setState(() {
        isLoading = false;
      });
    }
  }

  void connectToDevice(BluetoothDevice device) async {
    setState(() {
      isLoading = true;
    });
    device.connect().timeout(
      Duration(seconds: 10),
      onTimeout: () {
        device.disconnect();
        setState(() {
          isLoading = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text("Unable to Connect"),
        ));
      },
    );
    late StreamSubscription<BluetoothDeviceState> stateSub;
    stateSub = device.state.listen((state) {
      if (state == BluetoothDeviceState.connected) {
        setState(() {
          isLoading = false;
        });
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => SuggestedPrograms(d: device),
          ),
        );
        stateSub.cancel();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Image.asset("assets/wellverse_mini.png", scale: 2),
        centerTitle: true,
        actions: [IconButton(onPressed: () {}, icon: Icon(Icons.menu))],
      ),
      body: LoadingOverlay(
        isLoading: isLoading,
        child: Padding(
          padding: EdgeInsets.symmetric(
            vertical: 15,
            horizontal: (MediaQuery.of(context).size.width - 340) / 2,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                children: [
                  Text(
                    "Finding bands nearby..",
                    style: headingStyle,
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    "Make sure bluetooth is turned on",
                    style: TextStyle(fontSize: 14, color: Color(0x80346680)),
                  ),
                ],
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: showScanResults
                      ? ListView.builder(
                          shrinkWrap: true,
                          physics: const ClampingScrollPhysics(),
                          itemCount: scanResultList.length,
                          itemBuilder: (context, index) {
                            return listItem(scanResultList[index]);
                          },
                        )
                      : Image.asset(
                          "assets/connecting_mate.png",
                          scale: 2.5,
                        ),
                ),
              ),
              showScanResults
                  ? SizedBox(
                      width: 340,
                      height: 60,
                      child: OutlinedButton(
                        onPressed: () {
                          scan();
                        },
                        child: Text(
                          "Refresh",
                          style: purpleTextStyle,
                        ),
                        style: OutlinedButton.styleFrom(
                            side: BorderSide(color: purpleverse, width: 3),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20))),
                      ))
                  : Padding(
                      padding: const EdgeInsets.only(bottom: 5.0),
                      child: SizedBox(
                        width: 340,
                        height: 60,
                        child: TextButton(
                          onPressed: () {
                            setState(() {
                              scan();
                              showScanResults = true;
                            });
                          },
                          style: TextButton.styleFrom(
                              backgroundColor: purpleverse,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20))),
                          child: Text(
                            "Connect",
                            style: whiteTextStyle,
                          ),
                        ),
                      ),
                    )
            ],
          ),
        ),
      ),
    );
  }

  Widget deviceSignal(ScanResult r) {
    return Text(
      r.rssi.toString(),
    );
  }

  Widget deviceMacAddress(ScanResult r) {
    return Text(
      r.device.id.id,
    );
  }

  Widget deviceName(ScanResult r) {
    String name = '';

    if (r.device.name.isNotEmpty) {
      name = r.device.name;
    } else if (r.advertisementData.localName.isNotEmpty) {
      name = r.advertisementData.localName;
    } else {
      name = 'N/A';
    }
    return Text(
      name,
    );
  }

  Widget leading(ScanResult r) {
    return CircleAvatar(
      child: Icon(
        Icons.bluetooth,
        color: Colors.white,
      ),
      backgroundColor: navyblue,
    );
  }

  void onTap(ScanResult r) async {
    setState(() {
      isLoading = true;
    });
    r.device.connect().timeout(
      Duration(seconds: 10),
      onTimeout: () {
        r.device.disconnect();
        setState(() {
          isLoading = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text("Unable to Connect"),
        ));
      },
    );
    late StreamSubscription<BluetoothDeviceState> stateSub;
    print("Starting to listen to if device is connected");
    stateSub = r.device.state.listen((state) {
      print(state);
      if (state == BluetoothDeviceState.connected) {
        setState(() {
          isLoading = false;
        });
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (context) => SuggestedPrograms(d: r.device)));
        stateSub.cancel();
      }
    });
  }
}
