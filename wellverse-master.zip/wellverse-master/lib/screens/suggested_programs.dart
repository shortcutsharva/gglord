import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/material.dart';
import 'package:flutter_blue/flutter_blue.dart';
import 'package:wellverse/screens/player.dart';
import 'package:wellverse/shared/program_card.dart';
import 'package:wellverse/shared/styles.dart';

import '../models/Song.dart';

class SuggestedPrograms extends StatefulWidget {
  SuggestedPrograms({Key? key, required BluetoothDevice this.d})
      : super(key: key);
  BluetoothDevice d;

  @override
  State<SuggestedPrograms> createState() => _SuggestedProgramsState();
}

class _SuggestedProgramsState extends State<SuggestedPrograms> {
  int? batteryPercentage; // State variable to hold battery percentage

  List jsonResult = [];
  TextEditingController searchController = TextEditingController();
  bool showSearchBar = false;

  final Stream<QuerySnapshot<Map<String, dynamic>>> songsStream =
      FirebaseFirestore.instance
          .collection("songs")
          .orderBy("songId")
          .snapshots();

  @override
  void initState() {
    super.initState();
    getBatteryPercentage(); // Call the function to retrieve battery percentage
  }

  void getBatteryPercentage() async {
    try {
      // Discover services
      List<BluetoothService> services = await widget.d.discoverServices();

      // Look for Battery service
      BluetoothService batteryService = services.firstWhere(
        (service) =>
            service.uuid.toString().toUpperCase() ==
            '0000180F-0000-1000-8000-00805F9B34FB',
        orElse: () => throw Exception('Battery service not found'),
      );

      // Look for Battery level characteristic
      BluetoothCharacteristic batteryLevelCharacteristic =
          batteryService.characteristics.firstWhere(
        (characteristic) =>
            characteristic.uuid.toString().toUpperCase() ==
            '00002A19-0000-1000-8000-00805F9B34FB',
        orElse: () => throw Exception('Battery level characteristic not found'),
      );

      // Read battery level
      List<int> value = await batteryLevelCharacteristic.read();
      int batteryPercentage = value.first;

      // Update battery percentage state variable
      setState(() {
        this.batteryPercentage = batteryPercentage;
      });
    } catch (e) {
      print('Failed to get battery percentage: $e');
      // If an error occurs, set batteryPercentage to null
      setState(() {
        this.batteryPercentage = null;
      });
    }
  }

  Function makeCallback(Song song) {
    void onStart(int loops, String? imgpath) {
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => Player(
                    d: widget.d,
                    currentPlayingSong:
                        song, //"200,400,100,250,100,400,100,250,100,500,100,250",
                    loops: loops,
                    cachedImgPath: imgpath,
                  )));
    }

    return onStart;
  }

  Icon _getBatteryIcon() {
    if (batteryPercentage == null) {
      return Icon(Icons.battery_unknown);
    } else if (batteryPercentage! >= 20) {
      return Icon(Icons.battery_full);
    } else {
      return Icon(Icons.battery_alert);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Image.asset("assets/wellverse_mini.png", scale: 2),
        actions: [
          Row(
            children: [
              _getBatteryIcon(), // Display battery icon based on percentage
              SizedBox(width: 5),
              Text(
                '${batteryPercentage ?? "Unknown"}%',
                style: TextStyle(fontSize: 14),
              ),
              SizedBox(width: 10),
              IconButton(
                onPressed: () {
                  setState(() {
                    showSearchBar = !showSearchBar;
                  });
                },
                icon: Icon(Icons.search),
              ),
            ],
          ),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(
          vertical: 30,
          horizontal: (MediaQuery.of(context).size.width - 340) / 2,
        ),
        child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: songsStream,
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              print("FIREBASE CONN ERROR\n");
              print(snapshot.error.runtimeType);
              print(snapshot.error);
              print("-------------------");
              FirebaseCrashlytics.instance.recordError(
                  snapshot.error, snapshot.stackTrace,
                  reason: "Firebase Connection Snapshot has error");
              return const Text("Something went wrong");
            }
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(
                child: CircularProgressIndicator(),
              );
            }

            List<QueryDocumentSnapshot<Map<String, dynamic>>> songs =
                snapshot.requireData.docs;

            if (searchController.text != "") {
              songs = songs.where((element) {
                return ((element.data() as Map)["title"] as String)
                    .toLowerCase()
                    .contains(searchController.text.toLowerCase());
              }).toList();
            }

            return ListView(
              addAutomaticKeepAlives: true,
              children: [
                Text(
                  "Pick from one of the programs we shortlisted for you...",
                  style: headingStyle,
                ),
                if (showSearchBar)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
                    child: TextField(
                      controller: searchController,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(50)),
                        hintText: 'Search...',
                      ),
                    ),
                  ),
                if (songs.isNotEmpty)
                  ...(songs.map((e) {
                    Map songMap = e.data() as Map;
                    Song currSong = Song(
                        title: songMap["title"],
                        desc: songMap["desc"],
                        songId: songMap["songId"],
                        imgpath: songMap["imgpath"],
                        songpath: songMap["songpath"]);
                    return Padding(
                      padding: const EdgeInsets.only(top: 15),
                      child: ProgramCard(
                        title: currSong.title,
                        desc: currSong.desc,
                        imgpath: currSong.imgpath,
                        callback: makeCallback(currSong),
                      ),
                    );
                  })),
                if (songs.isEmpty)
                  Padding(
                    padding: const EdgeInsets.all(32.0),
                    child: Center(child: Text("No Items here :(")),
                  ),
                Divider(
                  thickness: 2,
                  height: 60,
                ),
                if (batteryPercentage !=
                    null) // Show battery percentage if available
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        _getBatteryIcon(), // Display battery icon based on percentage
                        SizedBox(width: 5),
                        Text(
                          '$batteryPercentage%',
                          style: TextStyle(fontSize: 16),
                        ),
                      ],
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}
