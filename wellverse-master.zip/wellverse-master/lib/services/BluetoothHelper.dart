import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_blue/flutter_blue.dart';

void writeData(
    String data, BluetoothCharacteristic targetCharacteristic) async {
  List<int> bytes = utf8.encode(data);
  await targetCharacteristic.write(bytes);
}

void sendData(BluetoothDevice targetDevice, String msg) async {
  late BluetoothCharacteristic targetCharacteristic;
  List<BluetoothService> services = await targetDevice.discoverServices();
  //debugPrint(services.toString());
  for (var service in services) {
    //print(service);
    if (service.uuid.toString() == '6e400001-b5a3-f393-e0a9-e50e24dcca9e') {
      for (var characteristic in service.characteristics) {
        if (characteristic.uuid.toString() ==
            '6e400002-b5a3-f393-e0a9-e50e24dcca9e') {
          print("\n\n\n\nWriting Data\n\n\n\n");
          print(msg);
          targetCharacteristic = characteristic;
          writeData(msg, targetCharacteristic);
        }
      }
    }
  }
  print("Services discovered");
  //listenToResponse(targetCharacteristic);
}
