import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class Or extends StatelessWidget {
  double height;
  Or({Key? key, this.height = 40}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Expanded(
          child: Divider(
            thickness: 1,
            height: height,
            endIndent: 30,
          ),
        ),
        const Text(
          "or",
          style: TextStyle(color: Colors.grey),
        ),
        Expanded(
            child: Divider(
          thickness: 1,
          indent: 30,
          height: height,
        ))
      ],
    );
  }
}
