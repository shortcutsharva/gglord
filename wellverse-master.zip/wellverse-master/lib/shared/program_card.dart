import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:numberpicker/numberpicker.dart';
import 'package:wellverse/shared/styles.dart';

import 'imageHelper.dart';

class ProgramCard extends StatefulWidget {
  ProgramCard(
      {Key? key,
      required String this.title,
      required String this.desc,
      required String this.imgpath,
      required Function this.callback})
      : super(key: key);
  Function callback;
  String title;
  String imgpath;
  String desc;

  @override
  State<ProgramCard> createState() => _ProgramCardState();
}

class _ProgramCardState extends State<ProgramCard>
    with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true; //keeps widget alive even after some scroll

  int loops = 1;
  TextEditingController _controller = TextEditingController();
  final storageRef = FirebaseStorage.instance.ref();
  String? dowurl;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    storageRef.child(widget.imgpath).getDownloadURL().then((url) {
      //print(url);
      setState(() => dowurl = url);
      //print("${widget.imgpath}: ${url}");
    });
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      color: navyblue,
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              children: [
                dowurl == null
                    ? Image.asset(
                        "assets/images/ganapathi.png",
                        width: 150,
                      )
                    : CachedNetworkImage(
                        imageUrl: dowurl!,
                        width: 150,
                        errorWidget: onError,
                        placeholder: ((context, url) {
                          return Image.asset(
                            "assets/images/ganapathi.png",
                            width: 150,
                          );
                        }),
                      ),
                SizedBox(
                  width: 10,
                ),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        widget.title,
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        widget.desc,
                        style: TextStyle(color: Colors.white, fontSize: 12),
                      )
                    ],
                  ),
                ),
              ],
            ),
            Divider(
              thickness: 1,
              height: 20,
              color: Colors.white,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Text(
                  "No. of times: ",
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      icon: Icon(Icons.remove),
                      color: Colors.white,
                      onPressed: loops > 0
                          ? () {
                              if (loops > 0) {
                                setState(() {
                                  loops--;
                                });
                                _controller.text = loops.toString();
                              }
                            }
                          : null,
                    ),
                    GestureDetector(
                      onTap: () {
                        showDialog(
                            context: context,
                            builder: (_) {
                              return AlertDialog(
                                title: Text("Enter Number of loops"),
                                content: new TextField(
                                  controller: _controller,
                                  decoration: InputDecoration(
                                      labelText: "Enter chants"),
                                  keyboardType: TextInputType.number,
                                  inputFormatters: <TextInputFormatter>[
                                    FilteringTextInputFormatter.digitsOnly
                                  ], // Only numbers can be entered
                                ),
                                actions: [
                                  TextButton(
                                    child: Text("Cancel"),
                                    onPressed: () {
                                      Navigator.pop(context);
                                    },
                                  ),
                                  TextButton(
                                    child: Text("Ok"),
                                    onPressed: () {
                                      if (_controller.text != null &&
                                          _controller.text != "") {
                                        setState(() {
                                          loops = int.parse(_controller.text);
                                        });
                                      }

                                      Navigator.pop(context);
                                    },
                                  ),
                                ],
                              );
                            });
                      },
                      behavior: HitTestBehavior.translucent,
                      child: Padding(
                        padding:
                            EdgeInsets.symmetric(vertical: 16, horizontal: 20),
                        child: Text(
                          loops.toString(),
                          style: TextStyle(
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    IconButton(
                      icon: Icon(Icons.add),
                      color: Colors.white,
                      onPressed: (() {
                        setState(() {
                          loops++;
                          _controller.text = loops.toString();
                        });
                      }),
                    )
                  ],
                )
              ],
            ),
            // NumberPicker(
            //     selectedTextStyle: TextStyle(fontSize: 22, color: Colors.amber),
            //     textStyle: TextStyle(color: Colors.white),
            //     axis: Axis.horizontal,
            //     minValue: 1,
            //     haptics: true,
            //     maxValue: 1000,
            //     value: loops,
            //     onChanged: (value) => setState(() {
            //           loops = value;
            //         })),
            Divider(
              thickness: 1,
              height: 20,
              color: Colors.white,
            ),
            TextButton(
                onPressed: (() => widget.callback(loops, dowurl)),
                child: Text(
                  "Start Now",
                  style: whiteTextStyle,
                ))
          ],
        ),
      ),
    );
  }
}
