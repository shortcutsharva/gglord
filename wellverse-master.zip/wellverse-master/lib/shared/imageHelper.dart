import 'package:flutter/material.dart';

Widget onError(BuildContext context, String url, dynamic err) {
  print("ERROR LOADING IMAGE");
  print(err);
  print("--------------------");
  return Image.asset(
    "assets/images/ganapathi.png",
    width: 300,
  );
}
