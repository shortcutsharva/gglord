import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:wellverse/shared/styles.dart';

class PlanCard extends StatefulWidget {
  const PlanCard({Key? key}) : super(key: key);

  @override
  State<PlanCard> createState() => _PlanCardState();
}

class _PlanCardState extends State<PlanCard> {
  List<Widget> featuresColumn(List features) {
    List<Widget> featureRows = [];
    for (var element in features) {
      featureRows.add(Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: Row(
          children: [
            Icon(
              Icons.check,
              color: mustard,
            ),
            SizedBox(
              width: 10,
            ),
            Text(
              "Some premium features",
              style: TextStyle(color: Colors.white, fontSize: 13),
            )
          ],
        ),
      ));
    }
    return featureRows;
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      color: purpleverse,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(15.0, 20.0, 15.0, 20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Card(
                  color: mustard,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 3.0, horizontal: 7),
                    child: Text(
                      "Recommended",
                      style: TextStyle(fontSize: 10, color: navyblue),
                    ),
                  ),
                ),
                SizedBox(height: 13),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Monthly Plan",
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.normal,
                            color: Colors.white)),
                    Text(
                      "\$24",
                      style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.normal,
                          color: Colors.white),
                    )
                  ],
                ),
                Divider(
                  color: lightPurple,
                  thickness: 1,
                ),
              ],
            ),
            Column(
              children: featuresColumn([0, 1, 2, 3, 4]),
            ),
            SizedBox(
              height: 40,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom(
                    backgroundColor: navyblue,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10))),
                child: Text(
                  "Sign Up",
                  style: whiteTextStyle,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
