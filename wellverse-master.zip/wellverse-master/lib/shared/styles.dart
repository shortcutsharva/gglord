import 'package:flutter/material.dart';

Color purpleverse = Color(0xff7236B2);
Color navyblue = Color(0xff003466);
Color neonGreen = Color(0xff84DCC6);
Color lightPurple = Color(0xffA450FE);
Color mustard = Color(0xffF7B801);

LinearGradient purpleGradient =
    LinearGradient(colors: [Color(0xff9950FF), Color(0xff673F9E)]);

TextStyle whiteTextStyle = TextStyle(color: Colors.white);
TextStyle purpleTextStyle = TextStyle(color: purpleverse);
TextStyle headingStyle =
    TextStyle(fontSize: 24, color: navyblue, fontWeight: FontWeight.bold);

InputDecoration inputverse = InputDecoration(
    focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(color: neonGreen),
        borderRadius: BorderRadius.circular(10)),
    enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(color: Colors.grey),
        borderRadius: BorderRadius.circular(10)));
