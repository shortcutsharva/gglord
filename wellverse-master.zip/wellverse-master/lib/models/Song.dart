class Song {
  String title;
  String desc;
  String songId;
  String imgpath;
  String songpath;

  Song(
      {required this.title,
      required this.desc,
      required this.songId,
      required this.imgpath,
      required this.songpath});
}
